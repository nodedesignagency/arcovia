import type { CSSProperties } from "react";
import { Container } from "@/components/layout/Container";
import { TextReveal } from "@/components/motion/TextReveal";
import { Button } from "@/components/ui/Button";
import { CaseStudyCard } from "@/components/ui/CaseStudyCard";
import { sectionTextRevealDynamic } from "@/config/animation";
import type { CaseStudy } from "@/content/case-studies";

/**
 * Case studies — "Latest works".
 *
 * The heading and its supporting line sit left, the link to the full index
 * right, and the cards stack beneath. Only the first three appear here; the
 * rest live on /case-study, which is what the button is for.
 *
 * Takes the studies as a prop rather than fetching. Where they come from is
 * src/lib/case-studies.ts, and this stays a plain component that renders an
 * array — which is also what makes it trivial to render with demo content
 * before a CMS exists.
 */

/** How many the home page shows, regardless of how many are published. */
const SHOWN = 3;

type CaseStudiesProps = {
  /** The home page's `caseStudiesContent`, or any other of the same shape. */
  content: {
    headingLines: readonly string[];
    subheading: string;
    cta: { label: string; href: string };
  };
  studies: CaseStudy[];
  /** How many cards to show. The home page's three by default. */
  limit?: number;
  /**
   * The button to the full index beside the heading. On by default; a page
   * that should not send the reader off elsewhere (/vsl) turns it off.
   */
  showIndexLink?: boolean;
  /**
   * The line under the heading set to its right instead, where the index
   * button stands on the home page — /vsl, which has no button there and
   * sets every other section's line that way.
   */
  subheadingAside?: boolean;
};

export function CaseStudies({
  content,
  studies,
  limit = SHOWN,
  showIndexLink = true,
  subheadingAside = false,
}: CaseStudiesProps) {
  return (
    <section data-bg="green" className="bg-bg py-20 tablet:py-30">
      <Container>
        <div className="flex flex-col gap-8 tablet:flex-row tablet:items-end tablet:justify-between">
          <div>
            <TextReveal
              as="h2"
              lines={content.headingLines}
              settings={sectionTextRevealDynamic}
              className="flex flex-col items-start gap-(--space-heading-line) text-display-lg leading-(--leading-display) tracking-(--tracking-display) font-normal"
            />
            {subheadingAside ? null : (
              <p className="text-ink-dynamic mt-6 max-w-[46ch] font-body text-body-md">
                {content.subheading}
              </p>
            )}
          </div>

          {subheadingAside ? (
            <p className="text-ink-dynamic max-w-[40ch] font-body text-body-md tablet:pb-1">
              {content.subheading}
            </p>
          ) : null}

          {/* `self-start`: in the column this row becomes on a phone, a flex
              item stretches, and the original sizes this button to its own
              228 rather than the screen. */}
          {showIndexLink ? (
            <Button
              href={content.cta.href}
              variant="secondary"
              withArrow
              className="shrink-0 self-start"
            >
              {content.cta.label}
            </Button>
          ) : null}
        </div>

        {/* 10 between cards on a phone, per the owner. */}
        <div className="mt-15 flex flex-col gap-2.5 tablet:gap-5">
          {studies.slice(0, limit).map((study) => (
            <CaseStudyCard
              key={study.slug}
              study={study}
              // The rectangles are the panel's own colour, so a card's hover
              // reads as that card's tint arriving over the artwork rather
              // than a second, louder shade laid on top.
              style={
                {
                  "--mh-case-shape": `var(--color-case-${study.tone})`,
                } as CSSProperties
              }
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
