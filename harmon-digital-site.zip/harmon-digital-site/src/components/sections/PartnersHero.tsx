import { Container } from "@/components/layout/Container";
import { Parallax } from "@/components/motion/Parallax";
import { PatternField } from "@/components/motion/PatternField";
import { TextReveal } from "@/components/motion/TextReveal";
import { Button } from "@/components/ui/Button";
import type { CSSProperties } from "react";
import { heroParallax, mobileBand, sectionTextRevealDark } from "@/config/animation";


/**
 * The Referral Partners page's opening — a copy of the Careers hero
 * (CareersHero), which stays as it is.
 *
 * The same entrance: a full screen, pinned while the section below rides up
 * over it, the content ranged left and drifting as the stack travels, a single
 * pattern field down the right. One addition: a supporting line between the
 * heading and the button.
 *
 * A server component. The pattern, the reveal and the drift each declare the
 * client for themselves, so nothing else here ships to the browser.
 */

type PartnersHeroProps = {
  content: {
    /** Above the heading. Sentence case, not the site's uppercase eyebrow. */
    eyebrow: string;
    headingLines: readonly string[];
    headingLinesMobile: readonly string[];
    subheading: string;
    cta: { label: string; href: string };
  };
};

export function PartnersHero({ content }: PartnersHeroProps) {
  return (
    // `white` with the fill kept, exactly as the home hero: the changing layer
    // behind this is already the surface the *next* section wears, and the
    // hero simply covers it with its own dark fill until it is scrolled past.
    // Without `data-bg-keep` the takeover would repaint the page dark and the
    // handover to white would then have to be undone.
    <section
      data-bg="white"
      data-bg-keep=""
      // `100dvh` tracks mobile browser chrome as it hides and shows; the
      // `h-screen` fallback covers browsers without dynamic viewport units.
      className="sticky top-0 flex h-screen min-h-[40rem] items-center overflow-hidden bg-bg h-[100dvh] max-desktop:pt-(--mh-band-top) max-desktop:pb-(--mh-band-bottom)"
      // The band is laid over the section, not in it, so nothing about the
      // centring below knows it is there. These reserve its worst-case height
      // at each edge, so what the content is centred in is the gap between the
      // two bands rather than the whole screen. Worst case and not the band's
      // actual height because a band's rows are drawn per seed — see
      // `mobileBand`.
      style={
        {
          "--mh-band-top": `calc(var(--header-height) + ${mobileBand}px)`,
          "--mh-band-bottom": `${mobileBand}px`,
        } as CSSProperties
      }
    >
      {/* One field rather than the home page's two: the content is ranged
          left, so the right half is the only side with room, and a matching
          field on the left would sit under the heading.

          It starts below the header rather than running the full height — the
          header is opaque, so a full-height field is simply cut off at its
          edge and a bar caught halfway reads as clipped rather than placed.
          `top-*` alone would drop `inset-y-0` wholesale in the class merge and
          take `bottom` with it, so both edges are stated. */}
      {/* Desktop only, and the bands below for everything narrower. Between
          about 810 and 1000 the columns take the outer fifth of each side
          while the heading still runs most of the width, and white words over
          a pastel bar all but vanish; above that the heading clears them. */}
      <div className="hidden desktop:contents">
        <PatternField
          side="right"
          orientation="vertical"
          className="top-header bottom-0 right-[3.5%] w-[26%]"
        />
      </div>

      {/* Below the tablet breakpoint the arrangement turns ninety degrees, as
          it does on the home page: a narrow screen has no column to spare
          beside a left-ranged heading. */}
      {/* The band drifts with the words, on the same range and the same
          distance, so the two keep station instead of converging. Static, it
          sat at the top of the screen while the heading climbed into it —
          about 250px of scroll on a phone before they met. Only below desktop:
          above it the side columns are what the section carries, and those do
          not drift today.

          `absolute inset-0` so the fields inside resolve against the same box
          they did before — a transform makes this the containing block, and
          the box is the section's. */}
      <Parallax
        drift={heroParallax.drift}
        trackSelector="[data-scroll-stack]"
        range="top"
        className="absolute inset-0 desktop:hidden"
      >
        <PatternField side="top" orientation="horizontal" className="top-header" />
        <PatternField side="bottom" orientation="horizontal" className="bottom-0" />
      </Parallax>

      {/* The section is pinned, so the drift tracks the stack around it —
          keyed to the hero itself it would freeze for the whole time it is
          held at the top, which is precisely when it should be moving. */}
      <Parallax
        drift={heroParallax.drift}
        trackSelector="[data-scroll-stack]"
        range="top"
        className="relative z-10 w-full"
      >
        <Container className="flex flex-col items-start">
          {/* Not the site's `eyebrow` utility: that is uppercase, tracked out
              and 12px, and this line is set as body copy in the design.
              `green-soft` is the palette's DCFFE4 — the same pale green the
              footer's column labels settle into, which is already exposed as a
              token rather than being a fourth name for one colour. */}
          <p className="font-body text-body-md text-green-soft">{content.eyebrow}</p>

          <TextReveal
            as="h1"
            lines={content.headingLines}
            mobileLines={content.headingLinesMobile}
            settings={sectionTextRevealDark}
            lineStagger={sectionTextRevealDark.lineStagger}
            className="mt-6 flex flex-col items-start gap-(--space-heading-line) text-display-xl leading-(--leading-display) tracking-(--tracking-display) font-normal"
          />

          <p className="mt-6 max-w-[52ch] font-body text-body-md text-fg">
            {content.subheading}
          </p>

          {/* Fixed 267px from tablet up, full width on mobile — the site's
              call-to-action width. */}
          <Button
            href={content.cta.href}
            withArrow
            className="mt-10 w-full tablet:w-[267px]"
          >
            {content.cta.label}
          </Button>
        </Container>
      </Parallax>
    </section>
  );
}
